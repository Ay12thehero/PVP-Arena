/*    */ package me.Zizothehero.PvpArena;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Arena
/*    */ {
/* 11 */   public int id = 0;
/* 12 */   public Location spawn = null;
/* 13 */   List<String> players = new ArrayList();
/*    */   
/*    */   public Arena(Location loc, int id)
/*    */   {
/* 17 */     this.spawn = loc;
/* 18 */     this.id = id;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 22 */     return this.id;
/*    */   }
/*    */   
/*    */   public List<String> getPlayers() {
/* 26 */     return this.players;
/*    */   }
/*    */ }


/* Location:              C:\Users\pc\Desktop\Pvp Arena.jar!\me\Zizothehero\PvpArena\Arena.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */