/*    */ package me.Zizothehero.PvpArena;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.PlayerDeathEvent;
/*    */ import org.bukkit.scheduler.BukkitScheduler;
/*    */ 
/*    */ public class GameListener implements Listener
/*    */ {
/* 15 */   static List<String> players = new ArrayList();
/*    */   static ArenaPVP plugin;
/*    */   
/*    */   public GameListener(ArenaPVP plugin) {
/* 19 */     plugin = plugin;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onDamange(EntityDamageByEntityEvent e) {
/* 24 */     if (((e.getEntity() instanceof Player)) && (players.contains(((Player)e.getEntity()).getName()))) {
/* 25 */       e.setCancelled(true);
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onDeath(PlayerDeathEvent e) {
/* 31 */     if (ArenaManager.getManager().isInGame(e.getEntity())) {
/* 32 */       ArenaManager.getManager().removePlayer(e.getEntity());
/*    */     }
/*    */   }
/*    */   
/*    */   public static void add(Player p) {
/* 37 */     String name = p.getName();
/* 38 */     players.add(name);
/*    */     
/* 40 */     Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, new Runnable()
/*    */     {
/*    */       public void run() {
/* 43 */         GameListener.players.remove(GameListener.this);
/*    */       }
/* 45 */     }, 100L);
/*    */   }
/*    */ }


/* Location:              C:\Users\pc\Desktop\Pvp Arena.jar!\me\Zizothehero\PvpArena\GameListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */