/*     */ package me.Zizothehero.PvpArena;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ 
/*     */ public class ArenaManager
/*     */ {
/*  16 */   public Map<String, Location> locs = new HashMap();
/*     */   
/*  18 */   public static ArenaManager am = new ArenaManager();
/*     */   
/*  20 */   Map<String, ItemStack[]> inv = new HashMap();
/*  21 */   Map<String, ItemStack[]> armor = new HashMap();
/*     */   
/*  23 */   List<Arena> arenas = new ArrayList();
/*  24 */   int arenaSize = 0;
/*     */   static ArenaPVP plugin;
/*     */   
/*     */   public ArenaManager(ArenaPVP arenaPVP) {
/*  28 */     plugin = arenaPVP;
/*     */   }
/*     */   
/*     */ 
/*     */   public ArenaManager() {}
/*     */   
/*     */ 
/*     */   public static ArenaManager getManager()
/*     */   {
/*  37 */     return am;
/*     */   }
/*     */   
/*     */   public Arena getArena(int i)
/*     */   {
/*  42 */     for (Arena a : this.arenas) {
/*  43 */       if (a.getId() == i) {
/*  44 */         return a;
/*     */       }
/*     */     }
/*  47 */     return null;
/*     */   }
/*     */   
/*     */   public void addPlayer(Player p, int i)
/*     */   {
/*  52 */     Arena a = getArena(i);
/*  53 */     if (a == null) {
/*  54 */       p.sendMessage("Invalid arena!");
/*  55 */       return;
/*     */     }
/*     */     
/*  58 */     a.getPlayers().add(p.getName());
/*  59 */     this.inv.put(p.getName(), p.getInventory().getContents());
/*  60 */     this.armor.put(p.getName(), p.getInventory().getArmorContents());
/*     */     
/*  62 */     p.getInventory().setArmorContents(null);
/*  63 */     p.getInventory().clear();
/*     */     
/*  65 */     this.locs.put(p.getName(), p.getLocation());
/*  66 */     p.teleport(a.spawn);
/*     */   }
/*     */   
/*     */   public void removePlayer(Player p)
/*     */   {
/*  71 */     Arena a = null;
/*  72 */     for (Arena arena : this.arenas) {
/*  73 */       if (arena.getPlayers().contains(p.getName())) {
/*  74 */         a = arena;
/*     */       }
/*     */     }
/*     */     
/*  78 */     if ((a == null) || (!a.getPlayers().contains(p.getName()))) {
/*  79 */       p.sendMessage("Invalid operation!");
/*  80 */       return;
/*     */     }
/*     */     
/*  83 */     a.getPlayers().remove(p.getName());
/*     */     
/*  85 */     p.getInventory().clear();
/*  86 */     p.getInventory().setArmorContents(null);
/*     */     
/*  88 */     p.getInventory().setContents((ItemStack[])this.inv.get(p.getName()));
/*  89 */     p.getInventory().setArmorContents((ItemStack[])this.armor.get(p.getName()));
/*     */     
/*  91 */     this.inv.remove(p.getName());
/*  92 */     this.armor.remove(p.getName());
/*  93 */     p.teleport((Location)this.locs.get(p.getName()));
/*  94 */     this.locs.remove(p.getName());
/*     */     
/*  96 */     p.setFireTicks(0);
/*     */   }
/*     */   
/*     */   public Arena createArena(Location l)
/*     */   {
/* 101 */     int num = this.arenaSize + 1;
/* 102 */     this.arenaSize += 1;
/*     */     
/* 104 */     Arena a = new Arena(l, num);
/* 105 */     this.arenas.add(a);
/*     */     
/* 107 */     plugin.getConfig().set("Arenas." + num, serializeLoc(l));
/* 108 */     List<Integer> list = plugin.getConfig().getIntegerList("Arenas.Arenas");
/* 109 */     list.add(Integer.valueOf(num));
/* 110 */     plugin.getConfig().set("Arenas.Arenas", list);
/* 111 */     plugin.saveConfig();
/*     */     
/* 113 */     return a;
/*     */   }
/*     */   
/*     */   public Arena reloadArena(Location l) {
/* 117 */     int num = this.arenaSize + 1;
/* 118 */     this.arenaSize += 1;
/*     */     
/* 120 */     Arena a = new Arena(l, num);
/* 121 */     this.arenas.add(a);
/*     */     
/* 123 */     return a;
/*     */   }
/*     */   
/*     */   public void removeArena(int i) {
/* 127 */     Arena a = getArena(i);
/* 128 */     if (a == null) {
/* 129 */       return;
/*     */     }
/* 131 */     this.arenas.remove(a);
/*     */     
/* 133 */     plugin.getConfig().set("Arenas." + i, null);
/* 134 */     List<Integer> list = plugin.getConfig().getIntegerList("Arenas.Arenas");
/* 135 */     list.remove(i);
/* 136 */     plugin.getConfig().set("Arenas.Arenas", list);
/* 137 */     plugin.saveConfig();
/*     */   }
/*     */   
/*     */   public boolean isInGame(Player p) {
/* 141 */     for (Arena a : this.arenas) {
/* 142 */       if (a.getPlayers().contains(p.getName()))
/* 143 */         return true;
/*     */     }
/* 145 */     return false;
/*     */   }
/*     */   
/*     */   public void loadGames() {
/* 149 */     this.arenaSize = 0;
/*     */     
/* 151 */     if (plugin.getConfig().getIntegerList("Arenas.Arenas").isEmpty()) {
/* 152 */       return;
/*     */     }
/*     */     
/* 155 */     for (Iterator localIterator = plugin.getConfig().getIntegerList("Arenas.Arenas").iterator(); localIterator.hasNext();) { int i = ((Integer)localIterator.next()).intValue();
/* 156 */       Arena a = reloadArena(deserializeLoc(plugin.getConfig().getString("Arenas." + i)));
/* 157 */       a.id = i;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 162 */   public String serializeLoc(Location l) { return l.getWorld().getName() + "," + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ(); }
/*     */   
/*     */   public Location deserializeLoc(String s) {
/* 165 */     String[] st = s.split(",");
/* 166 */     return new Location(org.bukkit.Bukkit.getWorld(st[0]), Integer.parseInt(st[1]), Integer.parseInt(st[2]), Integer.parseInt(st[3]));
/*     */   }
/*     */ }


/* Location:              C:\Users\pc\Desktop\Pvp Arena.jar!\me\Zizothehero\PvpArena\ArenaManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */