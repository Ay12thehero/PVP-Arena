/*    */ package me.Zizothehero.PvpArena;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ArenaPVP extends org.bukkit.plugin.java.JavaPlugin
/*    */ {
/*    */   public void onEnable()
/*    */   {
/* 12 */     if (!getDataFolder().exists()) {
/* 13 */       getDataFolder().mkdir();
/*    */     }
/* 15 */     if (getConfig() == null) {
/* 16 */       saveDefaultConfig();
/*    */     }
/* 18 */     new ArenaManager(this);
/* 19 */     ArenaManager.getManager().loadGames();
/*    */     
/* 21 */     getServer().getPluginManager().registerEvents(new GameListener(this), this);
/*    */   }
/*    */   
/*    */   public void onDisable()
/*    */   {
/* 26 */     saveConfig();
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 31 */     if (!(sender instanceof Player)) {
/* 32 */       sender.sendMessage("Whoa there buddy, only players may execute this!");
/* 33 */       return true;
/*    */     }
/*    */     
/* 36 */     Player p = (Player)sender;
/*    */     
/* 38 */     if (cmd.getName().equalsIgnoreCase("create")) {
/* 39 */       ArenaManager.getManager().createArena(p.getLocation());
/* 40 */       p.sendMessage("Created arena at " + p.getLocation().toString());
/*    */       
/* 42 */       return true;
/*    */     }
/* 44 */     if (cmd.getName().equalsIgnoreCase("join")) {
/* 45 */       if (args.length != 1) {
/* 46 */         p.sendMessage("Joined!");
/* 47 */         return true;
/*    */       }
/* 49 */       int num = 0;
/*    */       try {
/* 51 */         num = Integer.parseInt(args[0]);
/*    */       } catch (NumberFormatException e) {
/* 53 */         p.sendMessage("Invalid arena ID");
/*    */       }
/* 55 */       ArenaManager.getManager().addPlayer(p, num);
/*    */       
/* 57 */       return true;
/*    */     }
/* 59 */     if (cmd.getName().equalsIgnoreCase("leave")) {
/* 60 */       ArenaManager.getManager().removePlayer(p);
/* 61 */       p.sendMessage("You have left the arena!");
/*    */       
/* 63 */       return true;
/*    */     }
/* 65 */     if (cmd.getName().equalsIgnoreCase("remove")) {
/* 66 */       if (args.length != 1) {
/* 67 */         p.sendMessage("Removed!");
/* 68 */         return true;
/*    */       }
/* 70 */       int num = 0;
/*    */       try {
/* 72 */         num = Integer.parseInt(args[0]);
/*    */       } catch (NumberFormatException e) {
/* 74 */         p.sendMessage("Invalid arena ID");
/*    */       }
/* 76 */       ArenaManager.getManager().removeArena(num);
/*    */       
/* 78 */       return true;
/*    */     }
/*    */     
/* 81 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pc\Desktop\Pvp Arena.jar!\me\Zizothehero\PvpArena\ArenaPVP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */